package assignment2;
import java.util.*;


public class RandomNumberGuesser 
{
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		String choice = "yes"; //choice on whether or not they want to play again
		int answer; //random number
		int guess; //user's guess
		
		int low = 0;
		int high = 101;
		boolean correct = false;
		
		do {
			RNG.resetCount(); //resets count to 0
			answer = RNG.rand(); //random number
			//System.out.println("Testing purposes: The answer is " + answer); // testing purposes
			System.out.println("This application generates a random integer between 1 and 100 and asks the user to guess repeatedly until they answer correctly.");
			System.out.println("Enter your first guess: ");
			//System.out.println(answer);
			for (int i = 1; i <= 7; i++)
			{
				do {
					guess = input.nextInt(); //get guess
					if (guess <= low || guess >= high) //if guess is not in range
					{
						RNG.inputValidation(guess, low, high);
						i--;
						System.out.println("Guesses used: " + i);
						System.out.println("Enter your next guess between " + low + " and " + high + ":");
					}
				} while(guess <= low || guess >= high);
				
				if (guess == answer) 
				{
					correct = true;
					break;
				}
				else //if guess does not equal answer
				{
					if (guess < answer)
					{
						low = guess;
						System.out.println("Your guess was too low.");
					}
					else //if guess > answer
					{
						high = guess;
						System.out.println("Your guess was too high.");
					}
					//i = RNG.getCount();
					System.out.println("Guesses used: " + i);
					if (i < 7)
					{
						System.out.println("Enter your next guess between " + low + " and " + high + ":");
					}
				}	
			}
			if (correct == false) //after 7 guesses, if they did not solve it
			{
				System.out.println("Sorry, you ran out of guesses.");
				System.out.println("The correct answer was " + answer);
			}
			else //after 7 guesses, if they did solve it
			{
				System.out.println("Congratulations, you guessed correctly!");
			}
			input.nextLine(); 
			do {
				System.out.println("Try again? (yes or no)");
				choice = input.nextLine();
				choice = choice.toLowerCase();
				if (choice.equals("no"))
				{
					break;
				}
				else if (!choice.equals("yes") && !choice.equals("no"))
				{
					System.out.println("Invalid choice, ");
				}
			} while (!choice.equals("yes") && !choice.equals("no"));
		} while(choice.equals("yes"));
		input.close();
	}
}