package lab1;
import java.util.*; 

public class MovieDriver 
{
	public static void main (String[] args)
	{
		Movie movie = new Movie();
		
		String movieTitle; 
		String movieRating; 
		int ticketsSold; //gtitle, ranking, sold tickets
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter the name of a movie ");
		movieTitle = input.nextLine();
		movie.setTitle(movieTitle);
		
		System.out.println("Enter the rating of the movie ");
		movieRating = input.nextLine();
		movie.setRating(movieRating);
		
		System.out.println("Enter the number of tickets sold for this movie ");
		ticketsSold = input.nextInt();
		movie.setSoldTickets(ticketsSold);
		
		System.out.print(movie.getTitle() + " (" + movie.getRating());
		System.out.print(") Tickets Sold: " + movie.getSoldTickets());
		
		input.close();
	}
}