package lab1;
import java.util.*; 

public class MovieDriver 
{
	public static void main (String[] args)
	{
		Movie movie = new Movie();
		
		String movieTitle; 
		String movieRating; 
		int ticketsSold; //gtitle, ranking, sold tickets
		char choice = 'y';
		Scanner input = new Scanner(System.in);
		
		do {
			System.out.println("Enter the name of a movie ");
			movieTitle = input.nextLine();
			movie.setTitle(movieTitle);
			
			System.out.println("Enter the rating of the movie ");
			movieRating = input.nextLine();
			movie.setRating(movieRating);
			
			System.out.println("Enter the number of tickets sold for this movie ");
			ticketsSold = input.nextInt();
			movie.setSoldTickets(ticketsSold);
			
			System.out.print(movie.getTitle() + " (" + movie.getRating());
			System.out.print(") Tickets Sold: " + movie.getSoldTickets());
			
			System.out.println("Do you want to enter another? (y or n) ");
			do {
				choice = input.next().charAt(0);
				if (choice != 'y' && choice != 'n')
				{
					
				}
				if (choice == 'n')
				{
					System.out.println("Goodbye");
				}
			}while (choice != 'y' && choice != 'n');
		}while(choice != 'n');
		
		input.close();
	}
}