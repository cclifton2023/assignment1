package gradeBook;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradeBookTest 
{
	private GradeBook grade1;
	private GradeBook grade2;
	
	@BeforeEach
	void setUp() throws Exception 
	{
		grade1 = new GradeBook(5);
	    grade2 = new GradeBook(5);

	    grade1.addScore(25.0);
	    grade1.addScore(45.0);
	    grade1.addScore(79.0);
	    grade1.addScore(87.7);

	    grade2.addScore(19.7);
	    grade2.addScore(49.8);
	    grade2.addScore(61.5);
	    grade2.addScore(100.0);
	}

	@AfterEach
	void tearDown() throws Exception {
		grade1 = null;
	    grade2 = null;
	}

	@Test
	void testAddScore() 
	{
		//For Debugging
		/* gb1.toString();
		System.out.println(gb1);
		gb2.toString();
		System.out.println(gb2);
		*/
		assertTrue(grade1.toString().equals("25.0 45.0 79.0 87.7 "));
		assertTrue(grade2.toString().equals("19.7 49.8 61.5 100.0 "));
	}

	@Test
	void testSum() 
	{
		assertEquals(236.7, grade1.sum(), .0001);
		assertEquals(231, grade2.sum(), .0001);
	
	}

	@Test
	void testMinimum() 
	{
		assertEquals(25.0, grade1.minimum(), .001);
		assertEquals(19.7, grade2.minimum(), .001);
	}

	@Test
	void testFinalScore() 
	{
		assertEquals(211.7, grade1.finalScore(), .001);
		assertEquals(211.3, grade2.finalScore(), .001);
		
	}
}
